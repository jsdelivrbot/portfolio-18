import React from 'react';
import { Component } from 'react';

import SearchBar from '../containers/search_bar';
import WeatherList from '../containers/weather_list';

export default class App extends Component {
  render() {
    return (
      <div>
      	<div className="topSec">
      		<h2 className="headline"><span className="wTitle">WEATHER</span>FINDER</h2>
      		<SearchBar />
      	</div>
      	<WeatherList />
      </div>
    );
  }
}
