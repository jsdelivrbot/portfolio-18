import React, { Component } from 'react';
import { connect } from 'react-redux';

class WeatherList extends Component {
	renderWeather(cityData){
		const name = cityData.name;
		const tempCurrent = Math.floor(1.8 *((cityData.main.temp) - 273) + 32);
		const tempHigh = Math.floor(1.8 *((cityData.main.temp_max) - 273) + 32);
		const tempLow = Math.floor(1.8 *((cityData.main.temp_min) - 273) + 32);
		const wind = cityData.wind.speed;
		const icon = cityData.weather[0].icon;
		const conditions = (cityData.weather[0].description).toUpperCase();
		const iconSource = `http://openweathermap.org/img/w/${icon}.png`;

		return(
			<tr key={name}>
				<td className="mainTemp">
					<h3 className="cityName">{name}</h3>
					<h4 className="temp">{tempCurrent}</h4>
				</td>
				<td className="tempRange">
					<h5>{tempLow} - {tempHigh}</h5>
					<p className="labels">L O W  -  H I G H</p>
				</td>
				<td className="conditions">
					<img className="weatherIcon" src={iconSource}></img>
					<p>{conditions}</p>
					<p className="labels">C O N D I T I O N S</p>
				</td>
				<td className="wind">
					<h5>{wind} mph</h5>
					<p className="labels">W I N D</p>
				</td>
			</tr>
		);	
	}

	render(){
		return(
			<table className="table">
				<tbody>
					{this.props.weather.map(this.renderWeather)}
				</tbody>
			</table>
		);
	}
}

function mapStateToProps({ weather }) {
	return { weather };
}

export default connect(mapStateToProps)(WeatherList);